"use client"

import * as React from "react"
import { useState } from "react"
import { Play, Plus, X, ListTodo, MessageSquare } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

type InputMode = "topic" | "tasks"

interface RunWorkflowDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onRun: (input: string) => void
  workflowName: string
}

export function RunWorkflowDialog({
  open,
  onOpenChange,
  onRun,
  workflowName,
}: RunWorkflowDialogProps) {
  const [mode, setMode] = useState<InputMode>("topic")
  const [topic, setTopic] = useState("")
  const [tasks, setTasks] = useState<string[]>([""])

  const handleAddTask = () => {
    setTasks((prev) => [...prev, ""])
  }

  const handleRemoveTask = (index: number) => {
    setTasks((prev) => prev.filter((_, i) => i !== index))
  }

  const handleTaskChange = (index: number, value: string) => {
    setTasks((prev) => prev.map((t, i) => (i === index ? value : t)))
  }

  const handleRun = () => {
    let input: string
    if (mode === "topic") {
      input = topic.trim()
    } else {
      const validTasks = tasks.filter((t) => t.trim().length > 0)
      input = `Task list:\n${validTasks.map((t, i) => `${i + 1}. ${t.trim()}`).join("\n")}`
    }

    if (!input) return
    onRun(input)
    onOpenChange(false)
    // Reset
    setTopic("")
    setTasks([""])
  }

  const isValid =
    mode === "topic"
      ? topic.trim().length > 0
      : tasks.some((t) => t.trim().length > 0)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg">Run Workflow</DialogTitle>
          <DialogDescription>
            Provide a topic or task list for{" "}
            <span className="font-medium text-foreground">{workflowName}</span>{" "}
            to process.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Mode Switcher */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setMode("topic")}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-lg border-2 p-3 text-sm font-medium transition-all min-h-[48px]",
                mode === "topic"
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-card text-muted-foreground hover:border-muted-foreground"
              )}
            >
              <MessageSquare className="h-4 w-4" />
              Topic / Prompt
            </button>
            <button
              type="button"
              onClick={() => setMode("tasks")}
              className={cn(
                "flex flex-1 items-center justify-center gap-2 rounded-lg border-2 p-3 text-sm font-medium transition-all min-h-[48px]",
                mode === "tasks"
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border bg-card text-muted-foreground hover:border-muted-foreground"
              )}
            >
              <ListTodo className="h-4 w-4" />
              Task List
            </button>
          </div>

          {/* Topic Input */}
          {mode === "topic" && (
            <div className="space-y-2">
              <Label htmlFor="workflow-topic">
                What should this workflow focus on?
              </Label>
              <Textarea
                id="workflow-topic"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Write a blog post about sustainable energy trends in 2026..."
                rows={4}
                className="resize-none text-base"
                autoFocus
              />
              <p className="text-xs text-muted-foreground">
                The first agent in the workflow will receive this as its starting context.
              </p>
            </div>
          )}

          {/* Task List Input */}
          {mode === "tasks" && (
            <div className="space-y-3">
              <Label>Define your task list</Label>
              <div className="space-y-2">
                {tasks.map((task, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-mono text-muted-foreground">
                      {index + 1}
                    </span>
                    <Input
                      value={task}
                      onChange={(e) => handleTaskChange(index, e.target.value)}
                      placeholder={`Task ${index + 1}...`}
                      className="text-base"
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault()
                          handleAddTask()
                        }
                      }}
                    />
                    {tasks.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 shrink-0"
                        onClick={() => handleRemoveTask(index)}
                        aria-label={`Remove task ${index + 1}`}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="w-full min-h-[44px] bg-transparent"
                onClick={handleAddTask}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Task
              </Button>
              <p className="text-xs text-muted-foreground">
                Press Enter to quickly add more tasks. The entire list is passed to the first agent.
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="bg-transparent">
            Cancel
          </Button>
          <Button
            onClick={handleRun}
            disabled={!isValid}
            className="gap-2 bg-status-success hover:bg-status-success/90 text-white"
          >
            <Play className="h-4 w-4" />
            Start Workflow
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
