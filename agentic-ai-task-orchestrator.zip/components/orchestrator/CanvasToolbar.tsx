"use client"

import * as React from "react"
import Link from "next/link"
import {
  Play,
  Pause,
  Square,
  RotateCcw,
  Save,
  FolderOpen,
  Plus,
  Loader2,
  Check,
  AlertCircle,
  FlaskConical,
  Menu,
  Sparkles,
  MoreVertical,
} from "lucide-react"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import { useWorkflowStore } from "@/lib/orchestrator/store"
import { getAllWorkflows } from "@/lib/orchestrator/persistence"
import type { WorkflowStatus, SavedWorkflow } from "@/lib/orchestrator/types"

const statusConfig: Record<
  WorkflowStatus,
  { label: string; icon: React.ReactNode; className: string }
> = {
  idle: {
    label: "Ready",
    icon: null,
    className: "bg-muted text-muted-foreground",
  },
  validating: {
    label: "Validating",
    icon: <Loader2 className="h-3 w-3 animate-spin" />,
    className: "bg-primary/20 text-primary",
  },
  running: {
    label: "Running",
    icon: <Loader2 className="h-3 w-3 animate-spin" />,
    className: "bg-primary/20 text-primary",
  },
  paused: {
    label: "Paused",
    icon: <Pause className="h-3 w-3" />,
    className: "bg-status-paused/20 text-status-paused",
  },
  success: {
    label: "Done",
    icon: <Check className="h-3 w-3" />,
    className: "bg-status-success/20 text-status-success",
  },
  error: {
    label: "Error",
    icon: <AlertCircle className="h-3 w-3" />,
    className: "bg-destructive/20 text-destructive",
  },
}

interface CanvasToolbarProps {
  onStartExecution: () => void
  onToggleMobileSidebar?: () => void
}

export function CanvasToolbar({
  onStartExecution,
  onToggleMobileSidebar,
}: CanvasToolbarProps) {
  const {
    workflowName,
    setWorkflowName,
    executionStatus,
    pauseExecution,
    cancelExecution,
    clearExecution,
    saveCurrentWorkflow,
    loadSavedWorkflow,
    newWorkflow,
    nodes,
    toggleTimeline,
    timelineOpen,
  } = useWorkflowStore()

  const [savedWorkflows, setSavedWorkflows] = React.useState<SavedWorkflow[]>(
    []
  )
  const [isEditing, setIsEditing] = React.useState(false)
  const [editedName, setEditedName] = React.useState(workflowName)

  React.useEffect(() => {
    setSavedWorkflows(getAllWorkflows())
  }, [])

  const handleSave = () => {
    saveCurrentWorkflow()
    setSavedWorkflows(getAllWorkflows())
  }

  const handleLoad = (id: string) => {
    loadSavedWorkflow(id)
    setSavedWorkflows(getAllWorkflows())
  }

  const handleNameSubmit = () => {
    setWorkflowName(editedName)
    setIsEditing(false)
  }

  const canRun = nodes.length > 0 && executionStatus === "idle"
  const isRunning =
    executionStatus === "running" || executionStatus === "validating"
  const isPaused = executionStatus === "paused"
  const isComplete =
    executionStatus === "success" || executionStatus === "error"
  const status = statusConfig[executionStatus]

  return (
    <header
      className="flex h-14 shrink-0 items-center border-b border-border bg-card"
      role="toolbar"
      aria-label="Workflow controls"
    >
      {/* ── Left: hamburger + brand + name ── */}
      <div className="flex items-center gap-1 pl-2 sm:gap-2 sm:pl-3 min-w-0">
        {/* Mobile hamburger */}
        {onToggleMobileSidebar && (
          <button
            type="button"
            onClick={onToggleMobileSidebar}
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-foreground transition-colors hover:bg-muted active:bg-muted/70 md:hidden"
            aria-label="Open agent library"
          >
            <Menu className="h-5 w-5" />
          </button>
        )}

        {/* Brand mark (compact on mobile) */}
        <div className="flex items-center gap-1.5 shrink-0">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="hidden sm:inline text-sm font-semibold text-foreground">
            AgentFlow
          </span>
        </div>

        {/* Divider */}
        <div className="hidden sm:block h-5 w-px bg-border mx-1" />

        {/* Editable workflow name */}
        <div className="min-w-0">
          {isEditing ? (
            <Input
              value={editedName}
              onChange={(e) => setEditedName(e.target.value)}
              onBlur={handleNameSubmit}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleNameSubmit()
                if (e.key === "Escape") {
                  setEditedName(workflowName)
                  setIsEditing(false)
                }
              }}
              className="h-8 w-36 sm:w-48 bg-background text-base"
              autoFocus
              aria-label="Workflow name"
            />
          ) : (
            <button
              type="button"
              onClick={() => {
                setEditedName(workflowName)
                setIsEditing(true)
              }}
              className="block truncate max-w-[100px] sm:max-w-[180px] text-sm font-medium text-foreground hover:text-primary transition-colors"
              aria-label="Edit workflow name"
            >
              {workflowName}
            </button>
          )}
        </div>

        {/* Status pill */}
        <span
          className={cn(
            "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold shrink-0 leading-none",
            status.className
          )}
          aria-live="polite"
        >
          {status.icon}
          <span className="hidden xs:inline sm:inline">{status.label}</span>
        </span>
      </div>

      {/* ── Center: execution controls ── */}
      <div className="flex items-center gap-1 sm:gap-1.5 mx-auto px-1">
        <TooltipProvider delayDuration={0}>
          {/* Run / Resume */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                onClick={onStartExecution}
                disabled={!canRun}
                className={cn(
                  "inline-flex h-11 items-center justify-center gap-1.5 rounded-lg px-3 sm:px-4 text-sm font-medium transition-colors",
                  "bg-status-success text-white hover:bg-status-success/90 active:bg-status-success/80",
                  "disabled:pointer-events-none disabled:opacity-40"
                )}
                aria-label="Run workflow"
              >
                <Play className="h-4 w-4" />
                <span className="hidden sm:inline">Run</span>
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Execute workflow</p>
            </TooltipContent>
          </Tooltip>

          {/* Pause (only while running) */}
          {isRunning && (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={pauseExecution}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground transition-colors hover:bg-muted active:bg-muted/70"
                  aria-label="Pause execution"
                >
                  <Pause className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Pause</p>
              </TooltipContent>
            </Tooltip>
          )}

          {/* Stop (running or paused) */}
          {(isRunning || isPaused) && (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={cancelExecution}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-destructive text-destructive-foreground transition-colors hover:bg-destructive/90 active:bg-destructive/80"
                  aria-label="Stop execution"
                >
                  <Square className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Stop</p>
              </TooltipContent>
            </Tooltip>
          )}

          {/* Reset (after complete) */}
          {isComplete && (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={clearExecution}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-lg border border-border bg-card text-foreground transition-colors hover:bg-muted active:bg-muted/70"
                  aria-label="Reset execution"
                >
                  <RotateCcw className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Reset</p>
              </TooltipContent>
            </Tooltip>
          )}
        </TooltipProvider>
      </div>

      {/* ── Right: utility actions ── */}
      <div className="flex items-center gap-0.5 pr-2 sm:pr-3">
        <TooltipProvider delayDuration={0}>
          {/* Timeline toggle -- visible on all sizes */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                onClick={toggleTimeline}
                className={cn(
                  "inline-flex h-11 items-center justify-center gap-1 rounded-lg px-2.5 text-xs font-medium transition-colors",
                  timelineOpen
                    ? "bg-secondary text-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground active:bg-muted/70"
                )}
                aria-label="Toggle execution timeline"
                aria-pressed={timelineOpen}
              >
                <span className="hidden sm:inline">Log</span>
                <span className="sm:hidden text-[10px]">Log</span>
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Execution timeline</p>
            </TooltipContent>
          </Tooltip>

          {/* Save -- icon only, always visible */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                onClick={handleSave}
                className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground active:bg-muted/70"
                aria-label="Save workflow"
              >
                <Save className="h-4 w-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Save</p>
            </TooltipContent>
          </Tooltip>

          {/* Overflow menu -- Load, New, Test Suite */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted hover:text-foreground active:bg-muted/70"
                aria-label="More actions"
              >
                <MoreVertical className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuItem onClick={() => newWorkflow()}>
                <Plus className="mr-2 h-4 w-4" />
                New Workflow
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {savedWorkflows.length > 0 ? (
                <>
                  {savedWorkflows.map((w) => (
                    <DropdownMenuItem
                      key={w.id}
                      onClick={() => handleLoad(w.id)}
                    >
                      <FolderOpen className="mr-2 h-4 w-4" />
                      {w.name}
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                </>
              ) : (
                <>
                  <DropdownMenuItem disabled>
                    <FolderOpen className="mr-2 h-4 w-4" />
                    No saved workflows
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                </>
              )}
              <DropdownMenuItem asChild>
                <Link href="/tests" className="flex items-center">
                  <FlaskConical className="mr-2 h-4 w-4" />
                  Test Suite
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </TooltipProvider>
      </div>
    </header>
  )
}
