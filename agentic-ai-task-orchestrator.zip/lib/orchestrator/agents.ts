import type { AgentDefinition, AgentType } from "./types"

export const AGENT_DEFINITIONS: Record<AgentType, AgentDefinition> = {
  researcher: {
    type: "researcher",
    name: "Researcher",
    description: "Gathers and analyzes information from provided context",
    icon: "Search",
    defaultSystemPrompt:
      "You are a skilled research assistant. Analyze the provided information thoroughly and extract key insights, facts, and relevant details. Be comprehensive but focused.",
    color: "hsl(189, 100%, 55%)",
  },
  writer: {
    type: "writer",
    name: "Writer",
    description: "Creates engaging written content based on inputs",
    icon: "PenTool",
    defaultSystemPrompt:
      "You are a professional content writer. Create clear, engaging, and well-structured content based on the provided context and requirements. Maintain a consistent tone and style.",
    color: "hsl(280, 65%, 60%)",
  },
  analyst: {
    type: "analyst",
    name: "Analyst",
    description: "Processes data and extracts meaningful insights",
    icon: "BarChart3",
    defaultSystemPrompt:
      "You are a data analyst expert. Examine the provided data or information, identify patterns, trends, and anomalies. Provide clear, actionable insights with supporting evidence.",
    color: "hsl(41, 100%, 70%)",
  },
  reviewer: {
    type: "reviewer",
    name: "Reviewer",
    description: "Quality checks and validates content or code",
    icon: "CheckCircle",
    defaultSystemPrompt:
      "You are a meticulous quality reviewer. Examine the provided content for accuracy, completeness, consistency, and quality. Identify issues and suggest specific improvements.",
    color: "hsl(142, 76%, 45%)",
  },
  summarizer: {
    type: "summarizer",
    name: "Summarizer",
    description: "Condenses information into concise summaries",
    icon: "FileText",
    defaultSystemPrompt:
      "You are an expert at distilling information. Create clear, concise summaries that capture the essential points. Preserve key details while eliminating redundancy.",
    color: "hsl(220, 70%, 60%)",
  },
  coder: {
    type: "coder",
    name: "Coder",
    description: "Generates, reviews, or refactors code",
    icon: "Code",
    defaultSystemPrompt:
      "You are an expert software developer. Write clean, efficient, and well-documented code. Follow best practices and explain your implementation decisions when relevant.",
    color: "hsl(0, 84%, 60%)",
  },
}

export const AGENT_LIST = Object.values(AGENT_DEFINITIONS)

export function getAgentDefinition(type: AgentType): AgentDefinition {
  return AGENT_DEFINITIONS[type]
}

export function getAgentIcon(type: AgentType): string {
  return AGENT_DEFINITIONS[type].icon
}

export function getAgentColor(type: AgentType): string {
  return AGENT_DEFINITIONS[type].color
}
