import type {
  WorkflowNode,
  WorkflowEdge,
  AgentNodeData,
  ApprovalGateNodeData,
  NodeExecutionResult,
} from "./types"

interface ExecutionCallbacks {
  onNodeStart: (nodeId: string) => void
  onNodeProgress: (nodeId: string, message: string) => void
  onNodeComplete: (result: NodeExecutionResult) => void
  onNodeError: (nodeId: string, error: string) => void
  onApprovalRequired: (nodeId: string) => void
  onWorkflowComplete: () => void
  onWorkflowError: (error: string) => void
  getExecutionStatus: () => string
  getNodeResults: () => Record<string, NodeExecutionResult>
}

// Topological sort to determine execution order
function topologicalSort(
  nodes: WorkflowNode[],
  edges: WorkflowEdge[]
): WorkflowNode[] {
  const nodeMap = new Map(nodes.map((n) => [n.id, n]))
  const inDegree = new Map<string, number>()
  const adjacency = new Map<string, string[]>()

  // Initialize
  for (const node of nodes) {
    inDegree.set(node.id, 0)
    adjacency.set(node.id, [])
  }

  // Build graph
  for (const edge of edges) {
    const targets = adjacency.get(edge.source) || []
    targets.push(edge.target)
    adjacency.set(edge.source, targets)
    inDegree.set(edge.target, (inDegree.get(edge.target) || 0) + 1)
  }

  // Find nodes with no incoming edges
  const queue: string[] = []
  for (const [id, degree] of inDegree) {
    if (degree === 0) {
      queue.push(id)
    }
  }

  const sorted: WorkflowNode[] = []
  while (queue.length > 0) {
    const nodeId = queue.shift()!
    const node = nodeMap.get(nodeId)
    if (node) {
      sorted.push(node)
    }

    const neighbors = adjacency.get(nodeId) || []
    for (const neighbor of neighbors) {
      const newDegree = (inDegree.get(neighbor) || 0) - 1
      inDegree.set(neighbor, newDegree)
      if (newDegree === 0) {
        queue.push(neighbor)
      }
    }
  }

  return sorted
}

// Get upstream node outputs for a given node
function getUpstreamOutputs(
  nodeId: string,
  edges: WorkflowEdge[],
  nodeResults: Record<string, NodeExecutionResult>
): Record<string, unknown> {
  const context: Record<string, unknown> = {}

  for (const edge of edges) {
    if (edge.target === nodeId) {
      const sourceResult = nodeResults[edge.source]
      if (sourceResult?.output) {
        context[edge.source] = sourceResult.output
      }
    }
  }

  return context
}

// Execute a single agent node
async function executeAgentNode(
  node: WorkflowNode,
  context: Record<string, unknown>,
  callbacks: ExecutionCallbacks
): Promise<NodeExecutionResult> {
  const data = node.data as AgentNodeData
  const startTime = Date.now()

  callbacks.onNodeStart(node.id)
  callbacks.onNodeProgress(node.id, "Initializing agent...")

  try {
    callbacks.onNodeProgress(node.id, "Calling AI model...")

    // Build the user prompt from context
    const contextKeys = Object.keys(context)
    let userPrompt: string

    if (contextKeys.length > 0) {
      userPrompt = `Based on the context provided from previous workflow steps, complete your task as defined in your system prompt.`
    } else {
      userPrompt = "No specific user input was provided. Use your system prompt to autonomously begin your task. Generate original content based on your expertise and current knowledge."
    }

    const response = await fetch("/api/orchestrate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        agentType: data.agentType,
        systemPrompt: data.systemPrompt,
        userPrompt,
        context,
        model: data.model,
        temperature: data.temperature,
        maxTokens: data.maxTokens,
      }),
    })

    const result = await response.json()

    if (!result.success) {
      throw new Error(result.error || "Agent execution failed")
    }

    const endTime = Date.now()
    const executionResult: NodeExecutionResult = {
      nodeId: node.id,
      status: "success",
      output: result.output,
      startTime,
      endTime,
      executionTime: endTime - startTime,
    }

    callbacks.onNodeComplete(executionResult)
    return executionResult
  } catch (error) {
    const endTime = Date.now()
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error"

    const executionResult: NodeExecutionResult = {
      nodeId: node.id,
      status: "error",
      error: errorMessage,
      startTime,
      endTime,
      executionTime: endTime - startTime,
    }

    callbacks.onNodeError(node.id, errorMessage)
    return executionResult
  }
}

// Execute workflow
export async function executeWorkflow(
  nodes: WorkflowNode[],
  edges: WorkflowEdge[],
  callbacks: ExecutionCallbacks,
  workflowInput?: string
): Promise<void> {
  // Sort nodes topologically
  const sortedNodes = topologicalSort(nodes, edges)

  // Track results
  const results: Record<string, NodeExecutionResult> = {}

  // If there's workflow input, add it to the start node result
  const startNode = sortedNodes.find((n) => n.type === "startNode")
  if (startNode && workflowInput) {
    results[startNode.id] = {
      nodeId: startNode.id,
      status: "success",
      output: workflowInput,
      startTime: Date.now(),
      endTime: Date.now(),
      executionTime: 0,
    }
    callbacks.onNodeComplete(results[startNode.id])
  }

  // Execute each node in order
  for (const node of sortedNodes) {
    // Check if execution was cancelled
    if (callbacks.getExecutionStatus() === "idle") {
      return
    }

    // Skip start node if already processed
    if (node.type === "startNode") {
      if (!results[node.id]) {
        callbacks.onNodeStart(node.id)
        results[node.id] = {
          nodeId: node.id,
          status: "success",
          output: workflowInput || "Workflow started",
          startTime: Date.now(),
          endTime: Date.now(),
          executionTime: 0,
        }
        callbacks.onNodeComplete(results[node.id])
      }
      continue
    }

    // Handle end node
    if (node.type === "endNode") {
      callbacks.onNodeStart(node.id)

      // Collect all outputs
      const allOutputs = Object.values(callbacks.getNodeResults())
        .filter((r) => r.output)
        .map((r) => r.output)
        .join("\n\n---\n\n")

      results[node.id] = {
        nodeId: node.id,
        status: "success",
        output: allOutputs,
        startTime: Date.now(),
        endTime: Date.now(),
        executionTime: 0,
      }
      callbacks.onNodeComplete(results[node.id])
      callbacks.onWorkflowComplete()
      return
    }

    // Handle approval gate
    if (node.type === "approvalGateNode") {
      callbacks.onNodeStart(node.id)
      callbacks.onApprovalRequired(node.id)

      // Wait for approval (this will pause execution)
      // The resumeExecution callback will handle continuing
      return
    }

    // Handle agent nodes
    if (node.type === "agentNode") {
      const context = getUpstreamOutputs(node.id, edges, {
        ...results,
        ...callbacks.getNodeResults(),
      })

      const result = await executeAgentNode(node, context, callbacks)
      results[node.id] = result

      // If error, stop execution
      if (result.status === "error") {
        callbacks.onWorkflowError(result.error || "Agent execution failed")
        return
      }
    }
  }
}

// Resume execution after approval
export async function resumeWorkflowAfterApproval(
  nodes: WorkflowNode[],
  edges: WorkflowEdge[],
  approvedNodeId: string,
  callbacks: ExecutionCallbacks
): Promise<void> {
  // Find the approved node's position in the sorted order
  const sortedNodes = topologicalSort(nodes, edges)
  const approvedIndex = sortedNodes.findIndex((n) => n.id === approvedNodeId)

  if (approvedIndex === -1) {
    callbacks.onWorkflowError("Approved node not found in workflow")
    return
  }

  // Mark approval node as complete
  const approvalResult: NodeExecutionResult = {
    nodeId: approvedNodeId,
    status: "success",
    output: "Approved",
    startTime: Date.now(),
    endTime: Date.now(),
    executionTime: 0,
  }
  callbacks.onNodeComplete(approvalResult)

  // Continue execution from the next node
  const remainingNodes = sortedNodes.slice(approvedIndex + 1)

  for (const node of remainingNodes) {
    // Check if execution was cancelled
    if (callbacks.getExecutionStatus() === "idle") {
      return
    }

    // Handle end node
    if (node.type === "endNode") {
      callbacks.onNodeStart(node.id)

      const allOutputs = Object.values(callbacks.getNodeResults())
        .filter((r) => r.output)
        .map((r) => r.output)
        .join("\n\n---\n\n")

      const endResult: NodeExecutionResult = {
        nodeId: node.id,
        status: "success",
        output: allOutputs,
        startTime: Date.now(),
        endTime: Date.now(),
        executionTime: 0,
      }
      callbacks.onNodeComplete(endResult)
      callbacks.onWorkflowComplete()
      return
    }

    // Handle approval gate
    if (node.type === "approvalGateNode") {
      callbacks.onNodeStart(node.id)
      callbacks.onApprovalRequired(node.id)
      return
    }

    // Handle agent nodes
    if (node.type === "agentNode") {
      const context = getUpstreamOutputs(node.id, edges, callbacks.getNodeResults())
      const result = await executeAgentNode(node, context, callbacks)

      if (result.status === "error") {
        callbacks.onWorkflowError(result.error || "Agent execution failed")
        return
      }
    }
  }
}
