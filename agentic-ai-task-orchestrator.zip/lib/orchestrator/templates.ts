import type { WorkflowTemplate, WorkflowNode, WorkflowEdge } from "./types"
import { AGENT_DEFINITIONS } from "./agents"

function createAgentNode(
  id: string,
  agentType: keyof typeof AGENT_DEFINITIONS,
  label: string,
  position: { x: number; y: number },
  systemPromptOverride?: string
): WorkflowNode {
  const agent = AGENT_DEFINITIONS[agentType]
  return {
    id,
    type: "agentNode",
    position,
    data: {
      label,
      agentType,
      systemPrompt: systemPromptOverride || agent.defaultSystemPrompt,
      model: "openai/gpt-5.2",
      temperature: 0.7,
      maxTokens: 2048,
      inputMapping: {},
      status: "idle",
    },
  }
}

function createStartNode(
  id: string,
  position: { x: number; y: number }
): WorkflowNode {
  return {
    id,
    type: "startNode",
    position,
    data: { label: "Start", status: "idle" },
  }
}

function createEndNode(
  id: string,
  position: { x: number; y: number }
): WorkflowNode {
  return {
    id,
    type: "endNode",
    position,
    data: { label: "End", status: "idle" },
  }
}

function createApprovalNode(
  id: string,
  label: string,
  description: string,
  position: { x: number; y: number },
  options: string[] = ["Approve", "Reject", "Request Changes"]
): WorkflowNode {
  return {
    id,
    type: "approvalGateNode",
    position,
    data: { label, description, approvalOptions: options, status: "idle" },
  }
}

function createEdge(source: string, target: string): WorkflowEdge {
  return {
    id: `edge-${source}-${target}`,
    source,
    target,
    style: { strokeWidth: 2 },
  }
}

// ── Template 1: Content Review Pipeline ──────────────────────────────
const contentReviewPipeline: WorkflowTemplate = {
  id: "content-review",
  name: "Content Review Pipeline",
  description:
    "Enter a topic or brief -- the Writer drafts content, the Reviewer critiques it, then you approve before final output.",
  nodes: [
    createStartNode("start", { x: 50, y: 200 }),
    createAgentNode(
      "writer",
      "writer",
      "Content Writer",
      { x: 250, y: 200 },
      "You are a professional content writer. The user will provide a topic or brief. Write a compelling, well-structured article of 300-500 words on that topic. Use clear headings and engaging prose."
    ),
    createAgentNode(
      "reviewer",
      "reviewer",
      "Quality Reviewer",
      { x: 500, y: 200 },
      "You are a meticulous editor. Review the draft for clarity, accuracy, grammar, and engagement. Provide 3 specific suggestions and rate the content 1-10."
    ),
    createApprovalNode(
      "approval",
      "Editorial Approval",
      "Read the draft and reviewer feedback. Approve for publication, reject, or request revisions.",
      { x: 750, y: 200 }
    ),
    createEndNode("end", { x: 1000, y: 200 }),
  ],
  edges: [
    createEdge("start", "writer"),
    createEdge("writer", "reviewer"),
    createEdge("reviewer", "approval"),
    createEdge("approval", "end"),
  ],
}

// ── Template 2: Research & Summarize ─────────────────────────────────
const researchSummarize: WorkflowTemplate = {
  id: "research-summarize",
  name: "Research & Summarize",
  description:
    "Provide a research question, topic, or list of resources. The Researcher investigates, the Analyst finds patterns, and the Summarizer distils an executive brief.",
  nodes: [
    createStartNode("start", { x: 50, y: 200 }),
    createAgentNode(
      "researcher",
      "researcher",
      "Topic Researcher",
      { x: 250, y: 200 },
      "You are a thorough researcher. The user will provide a topic, question, or resource list. Investigate deeply: gather key facts, identify relevant data points, and note important nuances. Be comprehensive."
    ),
    createAgentNode(
      "analyst",
      "analyst",
      "Pattern Analyst",
      { x: 500, y: 200 },
      "You are a skilled analyst. Given the research findings, identify the top 3 patterns or trends. Evaluate reliability and highlight actionable insights."
    ),
    createAgentNode(
      "summarizer",
      "summarizer",
      "Executive Summarizer",
      { x: 750, y: 200 },
      "You create executive summaries. Distil the analysis into a concise brief (under 400 words) with key takeaways, critical findings, and recommended next steps."
    ),
    createEndNode("end", { x: 1000, y: 200 }),
  ],
  edges: [
    createEdge("start", "researcher"),
    createEdge("researcher", "analyst"),
    createEdge("analyst", "summarizer"),
    createEdge("summarizer", "end"),
  ],
}

// ── Template 3: Code Review Flow ─────────────────────────────────────
const codeReviewFlow: WorkflowTemplate = {
  id: "code-review",
  name: "Code Review Flow",
  description:
    "Describe the feature or paste code. The Coder writes or refactors, the Reviewer audits for bugs and best practices, and you approve for deployment.",
  nodes: [
    createStartNode("start", { x: 50, y: 200 }),
    createAgentNode(
      "coder",
      "coder",
      "Code Generator",
      { x: 250, y: 200 },
      "You are an expert developer. The user will describe a feature, bug fix, or paste existing code to refactor. Produce clean, well-documented code with error handling."
    ),
    createAgentNode(
      "code-reviewer",
      "reviewer",
      "Code Reviewer",
      { x: 500, y: 200 },
      "You are a senior code reviewer. Audit the code for bugs, security issues, performance, and best practices. Give specific line-level feedback and an overall quality rating."
    ),
    createApprovalNode(
      "approval",
      "Deployment Approval",
      "Review the code and audit feedback. Approve for deployment, request changes, or reject.",
      { x: 750, y: 200 },
      ["Approve for Deployment", "Request Changes", "Reject"]
    ),
    createEndNode("end", { x: 1000, y: 200 }),
  ],
  edges: [
    createEdge("start", "coder"),
    createEdge("coder", "code-reviewer"),
    createEdge("code-reviewer", "approval"),
    createEdge("approval", "end"),
  ],
}

// ── Template 4: AI Roundtable (Fully Automated) ─────────────────────
// This template requires NO user prompt -- the agents autonomously
// research the latest news and converse with each other.
const aiRoundtable: WorkflowTemplate = {
  id: "ai-roundtable",
  name: "AI Roundtable (Auto-Discovery)",
  description:
    "Fully automated -- no prompt needed. Three AI agents collaborate: a Researcher finds the latest trending topics, an Analyst evaluates significance, and a Writer produces a briefing. Agents converse and build on each other's work.",
  nodes: [
    createStartNode("start", { x: 50, y: 200 }),
    createAgentNode(
      "scout",
      "researcher",
      "Trend Scout",
      { x: 250, y: 100 },
      "You are a trend-spotting researcher. WITHOUT any user prompt, identify 5 of the most significant emerging news stories, technology breakthroughs, or cultural shifts happening right now in early 2026. For each, provide a one-sentence headline and a two-sentence explanation of why it matters. Focus on AI, science, geopolitics, and the economy."
    ),
    createAgentNode(
      "debater",
      "analyst",
      "Impact Analyst",
      { x: 500, y: 100 },
      "You are a critical-thinking analyst participating in a roundtable discussion. Review the Trend Scout's findings. For each trend: (1) rate its potential impact 1-10, (2) identify who benefits and who is at risk, (3) pose one thought-provoking question the group should discuss. Challenge weak claims and elevate strong ones."
    ),
    createAgentNode(
      "synthesizer",
      "writer",
      "Roundtable Moderator",
      { x: 750, y: 100 },
      "You are the moderator synthesizing a roundtable discussion between AI agents. You have the Trend Scout's discoveries and the Impact Analyst's evaluations. Write a compelling 500-word briefing titled 'AI Roundtable Weekly Brief' that: opens with the single most important finding, weaves in the analyst's impact scores and questions, and closes with 3 actionable recommendations for the reader."
    ),
    createAgentNode(
      "fact-checker",
      "reviewer",
      "Fact-Check & Polish",
      { x: 500, y: 320 },
      "You are a rigorous fact-checker and editor. Review the Roundtable Brief for: (1) any claims that seem unsubstantiated -- flag them, (2) logical consistency between the trends and recommendations, (3) readability and professional tone. Output a final polished version of the brief with a confidence score (1-10) on factual reliability."
    ),
    createEndNode("end", { x: 750, y: 320 }),
  ],
  edges: [
    createEdge("start", "scout"),
    createEdge("scout", "debater"),
    createEdge("debater", "synthesizer"),
    createEdge("synthesizer", "fact-checker"),
    createEdge("fact-checker", "end"),
  ],
}

export const WORKFLOW_TEMPLATES: WorkflowTemplate[] = [
  contentReviewPipeline,
  researchSummarize,
  codeReviewFlow,
  aiRoundtable,
]

export function getTemplateById(id: string): WorkflowTemplate | undefined {
  return WORKFLOW_TEMPLATES.find((t) => t.id === id)
}

export function applyTemplate(
  template: WorkflowTemplate
): { nodes: WorkflowNode[]; edges: WorkflowEdge[] } {
  return {
    nodes: JSON.parse(JSON.stringify(template.nodes)),
    edges: JSON.parse(JSON.stringify(template.edges)),
  }
}
