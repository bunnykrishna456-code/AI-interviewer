import { generateText } from "ai"
import { NextResponse } from "next/server"

export const maxDuration = 60

interface OrchestrateRequest {
  agentType: string
  systemPrompt: string
  userPrompt: string
  context?: Record<string, unknown>
  model?: string
  temperature?: number
  maxTokens?: number
}

export async function POST(request: Request) {
  try {
    const body: OrchestrateRequest = await request.json()

    const {
      systemPrompt,
      userPrompt,
      context,
      model = "openai/gpt-5.2",
      temperature = 0.7,
      maxTokens = 2048,
    } = body

    // Build the prompt with context if available
    let fullPrompt = userPrompt
    if (context && Object.keys(context).length > 0) {
      const contextStr = Object.entries(context)
        .map(([key, value]) => `[${key}]: ${JSON.stringify(value)}`)
        .join("\n\n")
      fullPrompt = `Context from previous nodes:\n${contextStr}\n\nTask:\n${userPrompt}`
    }

    const startTime = Date.now()

    const { text, usage, finishReason } = await generateText({
      model,
      system: systemPrompt,
      prompt: fullPrompt,
      maxOutputTokens: maxTokens,
      temperature,
    })

    const executionTime = Date.now() - startTime

    return NextResponse.json({
      success: true,
      output: text,
      usage,
      finishReason,
      executionTime,
    })
  } catch (error) {
    console.error("Orchestration error:", error)

    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Unknown error occurred",
      },
      { status: 500 }
    )
  }
}
