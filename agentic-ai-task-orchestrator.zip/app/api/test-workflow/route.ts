import { generateText } from "ai"
import { NextResponse } from "next/server"

export const maxDuration = 60

/**
 * Workflow integration test: simulates a 3-step agentic pipeline
 * Step 1 - Researcher generates findings
 * Step 2 - Analyst processes findings (receives Step 1 output as context)
 * Step 3 - Summarizer creates summary (receives Steps 1+2 as context)
 *
 * This validates:
 *  - Sequential agent execution
 *  - Context passing between nodes
 *  - Multi-step data flow
 *  - Model availability
 */

interface StepResult {
  step: number
  agent: string
  model: string
  success: boolean
  output?: string
  error?: string
  latency: number
}

async function runAgentStep(
  agent: string,
  systemPrompt: string,
  userPrompt: string,
  model: string
): Promise<StepResult> {
  const start = Date.now()
  try {
    const { text } = await generateText({
      model,
      system: systemPrompt,
      prompt: userPrompt,
      maxOutputTokens: 300,
      temperature: 0.5,
    })
    return {
      step: 0,
      agent,
      model,
      success: true,
      output: text,
      latency: Date.now() - start,
    }
  } catch (error) {
    return {
      step: 0,
      agent,
      model,
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      latency: Date.now() - start,
    }
  }
}

export async function POST(request: Request) {
  const totalStart = Date.now()
  const results: StepResult[] = []

  try {
    const body = await request.json()
    const model = body.model || "openai/gpt-5.2"
    const topic = body.topic || "the impact of renewable energy on global economies"

    // Step 1: Researcher
    const step1 = await runAgentStep(
      "Researcher",
      "You are an expert researcher. Provide 3 concise key findings about the given topic. Keep each finding to 1-2 sentences.",
      `Research topic: ${topic}`,
      model
    )
    step1.step = 1
    results.push(step1)

    if (!step1.success) {
      return NextResponse.json({
        success: false,
        error: `Step 1 (Researcher) failed: ${step1.error}`,
        results,
        totalLatency: Date.now() - totalStart,
      }, { status: 500 })
    }

    // Step 2: Analyst (receives researcher output)
    const step2 = await runAgentStep(
      "Analyst",
      "You are a data analyst. Analyze the provided research findings. Identify the most important trend and explain why it matters in 2-3 sentences.",
      `Research findings to analyze:\n${step1.output}`,
      model
    )
    step2.step = 2
    results.push(step2)

    if (!step2.success) {
      return NextResponse.json({
        success: false,
        error: `Step 2 (Analyst) failed: ${step2.error}`,
        results,
        totalLatency: Date.now() - totalStart,
      }, { status: 500 })
    }

    // Step 3: Summarizer (receives both outputs)
    const step3 = await runAgentStep(
      "Summarizer",
      "You are an executive summarizer. Create a 2-3 sentence executive summary from the research and analysis provided.",
      `Original research:\n${step1.output}\n\nAnalysis:\n${step2.output}`,
      model
    )
    step3.step = 3
    results.push(step3)

    if (!step3.success) {
      return NextResponse.json({
        success: false,
        error: `Step 3 (Summarizer) failed: ${step3.error}`,
        results,
        totalLatency: Date.now() - totalStart,
      }, { status: 500 })
    }

    // Validate data flow: check that step 3 output references something
    // from step 1 or step 2 (basic context propagation check)
    const contextFlowValid =
      step3.output &&
      step3.output.length > 20 &&
      step2.output &&
      step2.output.length > 20

    return NextResponse.json({
      success: true,
      contextFlowValid,
      results,
      summary: step3.output,
      totalLatency: Date.now() - totalStart,
      stepsCompleted: results.filter((r) => r.success).length,
      totalSteps: 3,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        results,
        totalLatency: Date.now() - totalStart,
      },
      { status: 500 }
    )
  }
}
