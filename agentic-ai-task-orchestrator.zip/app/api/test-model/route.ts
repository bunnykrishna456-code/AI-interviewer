import { generateText } from "ai"
import { NextResponse } from "next/server"

export const maxDuration = 30

// All models available through Vercel AI Gateway (zero-config)
export const SUPPORTED_MODELS = [
  { id: "openai/gpt-5.2", label: "GPT-5.2", provider: "OpenAI" },
  { id: "openai/gpt-4o", label: "GPT-4o", provider: "OpenAI" },
  { id: "anthropic/claude-sonnet-4-5", label: "Claude Sonnet 4.5", provider: "Anthropic" },
] as const

export type SupportedModelId = (typeof SUPPORTED_MODELS)[number]["id"]

interface TestModelRequest {
  model: string
  prompt?: string
}

export async function POST(request: Request) {
  const startTime = Date.now()

  try {
    const body: TestModelRequest = await request.json()
    const { model, prompt = "Respond with exactly: HELLO_AGENTFLOW_OK" } = body

    // Validate model is in our supported list
    const modelDef = SUPPORTED_MODELS.find((m) => m.id === model)
    if (!modelDef) {
      return NextResponse.json(
        {
          success: false,
          model,
          error: `Unsupported model: ${model}. Supported: ${SUPPORTED_MODELS.map((m) => m.id).join(", ")}`,
          latency: Date.now() - startTime,
        },
        { status: 400 }
      )
    }

    const { text, usage, finishReason } = await generateText({
      model,
      prompt,
      maxOutputTokens: 100,
      temperature: 0,
    })

    const latency = Date.now() - startTime

    return NextResponse.json({
      success: true,
      model,
      provider: modelDef.provider,
      label: modelDef.label,
      output: text,
      usage,
      finishReason,
      latency,
    })
  } catch (error) {
    const latency = Date.now() - startTime
    const message = error instanceof Error ? error.message : "Unknown error"

    return NextResponse.json(
      {
        success: false,
        model: "unknown",
        error: message,
        latency,
      },
      { status: 500 }
    )
  }
}

// GET endpoint to list all supported models
export async function GET() {
  return NextResponse.json({
    models: SUPPORTED_MODELS,
    gateway: "Vercel AI Gateway",
    note: "All models are available zero-config through the Vercel AI Gateway.",
  })
}
