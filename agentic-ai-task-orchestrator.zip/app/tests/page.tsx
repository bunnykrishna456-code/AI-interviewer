"use client"

import * as React from "react"
import { useState, useCallback } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Play,
  CheckCircle2,
  XCircle,
  Loader2,
  Clock,
  Zap,
  Network,
  RotateCcw,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"

// Types
interface ModelTestResult {
  model: string
  provider: string
  label: string
  success: boolean
  output?: string
  error?: string
  latency: number
  status: "idle" | "running" | "pass" | "fail"
}

interface WorkflowStepResult {
  step: number
  agent: string
  model: string
  success: boolean
  output?: string
  error?: string
  latency: number
}

interface WorkflowTestResult {
  success: boolean
  contextFlowValid?: boolean
  results: WorkflowStepResult[]
  summary?: string
  totalLatency: number
  stepsCompleted?: number
  totalSteps?: number
  error?: string
  status: "idle" | "running" | "pass" | "fail"
}

const MODELS_TO_TEST = [
  { id: "openai/gpt-5.2", label: "GPT-5.2", provider: "OpenAI" },
  { id: "openai/gpt-4o", label: "GPT-4o", provider: "OpenAI" },
  { id: "anthropic/claude-sonnet-4-5", label: "Claude Sonnet 4.5", provider: "Anthropic" },
]

function StatusIcon({ status }: { status: string }) {
  switch (status) {
    case "running":
      return <Loader2 className="h-4 w-4 animate-spin text-primary" />
    case "pass":
      return <CheckCircle2 className="h-4 w-4 text-status-success" />
    case "fail":
      return <XCircle className="h-4 w-4 text-destructive" />
    default:
      return <div className="h-4 w-4 rounded-full border-2 border-muted-foreground/30" />
  }
}

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    idle: "bg-muted text-muted-foreground",
    running: "bg-primary/20 text-primary",
    pass: "bg-status-success/20 text-status-success",
    fail: "bg-destructive/20 text-destructive",
  }
  return (
    <Badge className={cn("text-xs font-mono uppercase", variants[status] || variants.idle)}>
      {status}
    </Badge>
  )
}

export default function TestDashboard() {
  const [modelResults, setModelResults] = useState<ModelTestResult[]>(
    MODELS_TO_TEST.map((m) => ({
      model: m.id,
      provider: m.provider,
      label: m.label,
      success: false,
      latency: 0,
      status: "idle",
    }))
  )

  const [workflowResult, setWorkflowResult] = useState<WorkflowTestResult>({
    success: false,
    results: [],
    totalLatency: 0,
    status: "idle",
  })

  const [isRunningAll, setIsRunningAll] = useState(false)

  // Test a single model
  const testModel = useCallback(async (modelId: string): Promise<ModelTestResult> => {
    setModelResults((prev) =>
      prev.map((r) => (r.model === modelId ? { ...r, status: "running" } : r))
    )

    try {
      const res = await fetch("/api/test-model", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: modelId }),
      })

      const data = await res.json()

      const result: ModelTestResult = {
        model: data.model || modelId,
        provider: data.provider || "Unknown",
        label: data.label || modelId,
        success: data.success,
        output: data.output,
        error: data.error,
        latency: data.latency || 0,
        status: data.success ? "pass" : "fail",
      }

      setModelResults((prev) =>
        prev.map((r) => (r.model === modelId ? result : r))
      )

      return result
    } catch (err) {
      const errorResult: ModelTestResult = {
        model: modelId,
        provider: "Unknown",
        label: modelId,
        success: false,
        error: err instanceof Error ? err.message : "Network error",
        latency: 0,
        status: "fail",
      }
      setModelResults((prev) =>
        prev.map((r) => (r.model === modelId ? errorResult : r))
      )
      return errorResult
    }
  }, [])

  // Test the full workflow pipeline
  const testWorkflow = useCallback(async (): Promise<void> => {
    setWorkflowResult((prev) => ({ ...prev, status: "running", results: [], error: undefined }))

    try {
      const res = await fetch("/api/test-workflow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "openai/gpt-5.2",
          topic: "the impact of AI-powered workflow orchestration on software development productivity",
        }),
      })

      const data = await res.json()

      setWorkflowResult({
        success: data.success,
        contextFlowValid: data.contextFlowValid,
        results: data.results || [],
        summary: data.summary,
        totalLatency: data.totalLatency || 0,
        stepsCompleted: data.stepsCompleted,
        totalSteps: data.totalSteps,
        error: data.error,
        status: data.success ? "pass" : "fail",
      })
    } catch (err) {
      setWorkflowResult({
        success: false,
        results: [],
        totalLatency: 0,
        error: err instanceof Error ? err.message : "Network error",
        status: "fail",
      })
    }
  }, [])

  // Run all tests sequentially
  const runAllTests = useCallback(async () => {
    setIsRunningAll(true)

    // Reset everything
    setModelResults(
      MODELS_TO_TEST.map((m) => ({
        model: m.id,
        provider: m.provider,
        label: m.label,
        success: false,
        latency: 0,
        status: "idle",
      }))
    )
    setWorkflowResult({ success: false, results: [], totalLatency: 0, status: "idle" })

    // Run model tests sequentially to avoid rate limits
    for (const model of MODELS_TO_TEST) {
      await testModel(model.id)
    }

    // Run workflow test
    await testWorkflow()

    setIsRunningAll(false)
  }, [testModel, testWorkflow])

  // Summary stats
  const modelsPassed = modelResults.filter((r) => r.status === "pass").length
  const modelsFailed = modelResults.filter((r) => r.status === "fail").length
  const modelsTotal = modelResults.length
  const allModelsDone = modelResults.every((r) => r.status === "pass" || r.status === "fail")
  const workflowDone = workflowResult.status === "pass" || workflowResult.status === "fail"
  const totalTests = modelsTotal + 1
  const totalPassed = modelsPassed + (workflowResult.status === "pass" ? 1 : 0)
  const totalFailed = modelsFailed + (workflowResult.status === "fail" ? 1 : 0)
  const allDone = allModelsDone && workflowDone && !isRunningAll

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-20 flex h-14 items-center gap-4 border-b border-border bg-card/80 backdrop-blur-md px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors min-h-[44px] min-w-[44px] justify-center" aria-label="Back to orchestrator">
          <ArrowLeft className="h-5 w-5" />
          <span className="hidden sm:inline text-sm font-medium">Back</span>
        </Link>
        <Separator orientation="vertical" className="h-6" />
        <div className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          <h1 className="text-base font-semibold tracking-tight">AgentFlow Test Suite</h1>
        </div>
        <div className="ml-auto flex items-center gap-3">
          {allDone && totalPassed + totalFailed > 0 && (
            <Badge className={cn(
              "text-xs font-mono",
              totalFailed === 0
                ? "bg-status-success/20 text-status-success"
                : "bg-destructive/20 text-destructive"
            )}>
              {totalPassed}/{totalTests} passed
            </Badge>
          )}
          <Button
            onClick={runAllTests}
            disabled={isRunningAll}
            size="sm"
            className="gap-2 min-h-[44px] px-4"
          >
            {isRunningAll ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : allDone && totalPassed + totalFailed > 0 ? (
              <RotateCcw className="h-4 w-4" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            {isRunningAll ? "Running..." : allDone && totalPassed + totalFailed > 0 ? "Re-run All" : "Run All Tests"}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-6 space-y-6 max-w-5xl mx-auto w-full">
        {/* Model Tests Section */}
        <section aria-labelledby="model-tests-heading">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="h-5 w-5 text-primary" />
            <h2 id="model-tests-heading" className="text-lg font-semibold">AI Model Connectivity Tests</h2>
            <span className="text-xs text-muted-foreground font-mono">
              {modelsTotal} models via Vercel AI Gateway
            </span>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {modelResults.map((result) => (
              <Card key={result.model} className={cn(
                "transition-all duration-200",
                result.status === "pass" && "border-status-success/30",
                result.status === "fail" && "border-destructive/30",
                result.status === "running" && "border-primary/30",
              )}>
                <CardHeader className="pb-2 pt-4 px-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <StatusIcon status={result.status} />
                      <CardTitle className="text-sm font-medium">{result.label}</CardTitle>
                    </div>
                    <StatusBadge status={result.status} />
                  </div>
                </CardHeader>
                <CardContent className="px-4 pb-4 space-y-2">
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="font-mono">{result.provider}</span>
                    {result.latency > 0 && (
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {result.latency}ms
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-mono text-muted-foreground/80 break-all">{result.model}</p>
                  {result.output && (
                    <p className="text-xs text-foreground/80 truncate" title={result.output}>
                      {result.output}
                    </p>
                  )}
                  {result.error && (
                    <p className="text-xs text-destructive truncate" title={result.error}>
                      {result.error}
                    </p>
                  )}
                  {result.status === "idle" && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full text-xs min-h-[44px] bg-transparent"
                      onClick={() => testModel(result.model)}
                      disabled={isRunningAll}
                    >
                      <Play className="mr-1.5 h-3 w-3" />
                      Test Model
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <Separator />

        {/* Workflow Pipeline Test */}
        <section aria-labelledby="workflow-test-heading">
          <div className="flex items-center gap-3 mb-4">
            <Network className="h-5 w-5 text-accent" />
            <h2 id="workflow-test-heading" className="text-lg font-semibold">Agentic Workflow Pipeline Test</h2>
          </div>

          <Card className={cn(
            "transition-all duration-200",
            workflowResult.status === "pass" && "border-status-success/30",
            workflowResult.status === "fail" && "border-destructive/30",
            workflowResult.status === "running" && "border-primary/30",
          )}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <StatusIcon status={workflowResult.status} />
                  <div>
                    <CardTitle className="text-base">3-Step Agent Pipeline</CardTitle>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      Researcher &rarr; Analyst &rarr; Summarizer with context passing
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {workflowResult.totalLatency > 0 && (
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {(workflowResult.totalLatency / 1000).toFixed(1)}s total
                    </span>
                  )}
                  <StatusBadge status={workflowResult.status} />
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Validation badges */}
              {workflowResult.status === "pass" && (
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-status-success/20 text-status-success text-xs">
                    Sequential execution valid
                  </Badge>
                  {workflowResult.contextFlowValid && (
                    <Badge className="bg-status-success/20 text-status-success text-xs">
                      Context propagation valid
                    </Badge>
                  )}
                  <Badge className="bg-status-success/20 text-status-success text-xs">
                    {workflowResult.stepsCompleted}/{workflowResult.totalSteps} steps completed
                  </Badge>
                </div>
              )}

              {workflowResult.error && workflowResult.status === "fail" && (
                <p className="text-sm text-destructive">{workflowResult.error}</p>
              )}

              {/* Step results */}
              {workflowResult.results.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-muted-foreground">Step Results</h3>
                  {workflowResult.results.map((step) => (
                    <div
                      key={step.step}
                      className={cn(
                        "rounded-lg border p-3 space-y-2",
                        step.success ? "border-status-success/20 bg-status-success/5" : "border-destructive/20 bg-destructive/5"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <StatusIcon status={step.success ? "pass" : "fail"} />
                          <span className="text-sm font-medium">
                            Step {step.step}: {step.agent}
                          </span>
                        </div>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {step.latency}ms
                        </span>
                      </div>
                      {step.output && (
                        <ScrollArea className="max-h-24">
                          <p className="text-xs text-foreground/80 whitespace-pre-wrap">{step.output}</p>
                        </ScrollArea>
                      )}
                      {step.error && (
                        <p className="text-xs text-destructive">{step.error}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Summary output */}
              {workflowResult.summary && (
                <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 space-y-1">
                  <h3 className="text-sm font-medium text-primary">Final Summary Output</h3>
                  <p className="text-xs text-foreground/80 whitespace-pre-wrap">{workflowResult.summary}</p>
                </div>
              )}

              {workflowResult.status === "idle" && (
                <Button
                  variant="outline"
                  className="w-full min-h-[44px] bg-transparent"
                  onClick={testWorkflow}
                  disabled={isRunningAll}
                >
                  <Play className="mr-2 h-4 w-4" />
                  Run Workflow Test
                </Button>
              )}
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  )
}
